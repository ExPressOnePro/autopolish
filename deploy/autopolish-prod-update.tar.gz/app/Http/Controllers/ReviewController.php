<?php

namespace App\Http\Controllers;

use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class ReviewController extends Controller
{
    public function submit(Request $request)
    {
        $request->validate([
            'name' => 'nullable|string|max:50',
            'message' => 'nullable|string|max:500',
            'rating' => 'required|integer|min:1|max:5',
        ]);

        $userIp = $request->ip();

        $recentIpReview = Review::where('ip', $userIp)
            ->where('created_at', '>=', now()->subDay())
            ->first();

        if ($recentIpReview) {
            return response()->json([
                'status' => 'error',
                'message' => 'Вы уже оставили отзыв за последние 24 часа.'
            ]);
        }

        $review = Review::create([
            'name' => $request->name,
            'message' => $request->message,
            'rating' => $request->rating,
            'ip' => $userIp,
        ]);

        Cache::forget('landing.review_stats');

        return response()->json([
            'status' => 'success',
            'review' => $review
        ]);
    }


    public function list()
    {
        return Review::orderByDesc('created_at')->take(20)->get();
    }
}
