export const site = {
    name: 'Prime Detail',
    legalName: 'Полировка автомобилей',
    logo: '/images/logo.png',
    logoAlt: 'Auto Polishing — полировка автомобилей',
    phone: '+37369204272',
    phoneDisplay: '+373 69 204 272',
    phoneDigits: '37369204272',
    email: 'info@primedetail.md',
    whatsapp: 'https://wa.me/37369204272',
    telegram: 'https://t.me/+37369204272',
    address: {
        street: 'Strada Codrilor 8/5',
        city: 'Chișinău',
        country: 'Moldova',
        full: 'Strada Codrilor 8/5, Chișinău, Moldova',
    },
    geo: { lat: 47.0374211, lng: 28.7615023 },
    hours: 'Пн–Сб, 9:00–19:00',
    seo: {
        title: 'Полировка авто в Кишинёве | Prime Detail — детейлинг, керамика, PPF',
        description:
            'Профессиональная полировка и детейлинг авто в Кишинёве, str. Codrilor 8/5. Керамика, бронеплёнка PPF, подготовка к продаже. Запись: +37369204272 (WhatsApp, Telegram). Отзывы и цены.',
        keywords:
            'полировка авто кишинев, детейлинг кишинев, полировка автомобиля молдова, керамическое покрытие авто, PPF бронепленка, подготовка авто к продаже, полировка фар, Prime Detail',
        ogImage: '/images/logo.png',
    },
};
